from django import forms
from .models import Student


class Login(forms.ModelForm):
    class Meta:
        model = Student
        fields = '__all__'


class UpdateForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['Department']
