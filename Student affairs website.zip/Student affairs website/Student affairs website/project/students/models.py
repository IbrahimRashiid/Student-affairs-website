from tabnanny import verbose
from django.db import models

# Create your models here.


class Student(models.Model):
    x = [
        ('AI', 'AI'),
        ('IS', 'IS'),
        ('CS', 'CS'),
        ('IT', 'IT'),
        ('DS', 'DS'),
        ('General', 'General')
    ]

    y = [
        ('male', 'male'),
        ('female', 'female'),
    ]
    z = [
        ('level1', 'level1'),
        ('level2', 'level2'),
        ('level3', 'level3'),
        ('level4', 'level4'),
    ]
    s = [
        ('active', 'active'),
        ('inactive', 'inactive')
    ]

    name = models.CharField(max_length=50)
    ID = models.CharField(primary_key=True, max_length=50)
    Email = models.CharField(max_length=50)
    phone_num = models.CharField(max_length=15, verbose_name='Phone Nubmer')
    GPA = models.CharField(max_length=10)
    status = models.CharField(default='null', max_length=8, choices=s)
    Department = models.CharField(default='null', max_length=8, choices=x, null=True)
    Gender = models.CharField(default='null', max_length=6, choices=y)
    Date_of_Birth = models.DateField(verbose_name='Date Of Birth')
    Level = models.CharField(default='null', max_length=6, choices=z)
